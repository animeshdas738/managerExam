

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zayo.object.zObjManager;

public class DemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(false);
		if (session != null) {
		    session.invalidate();
		}
		response.sendRedirect("/TestJ2EEProject/managerScreen/managerHomeScreen.jsp");
		response.setContentType("text/html");//setting the content type  
		PrintWriter pw=response.getWriter();//get the stream to write the data  
		zObjManager manager = new zObjManager();
		manager.setManagerFirstName("Amit");
		manager.setManagerLastName("Grewal");
		manager.createZObject();
		//writing html in the stream  
		pw.println("<html><body>");  
		System.out.println("Testing");
		//pw.println("Welcome to servlet");  
		pw.println("<table><tr><td>"+ "Record ID"+"</td><td>"+ "First Name" +"</td><td>Last Name</td></tr></table>");
		pw.println("<table><tr><td>"+ manager.getRecordId()+"</td><td>"+ manager.getManagerFirstName() +"</td><td></td></tr></table>");  
		pw.println("</body></html>");  
		  
		pw.close();//closing the stream  
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
