package com.zayo.database;

import java.sql.*;
import java.util.ArrayList;
import com.zayo.object.zObjManager;

public class zayodbConnection {
	
	private static Connection zayodbConnection;
	
	public zayodbConnection(){
		
	}

	private static void initConnection(){
		zayodbConnection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			zayodbConnection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ANIMESHDAS","welcome1");  
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void closeConnection(){
		try {
			zayodbConnection.close();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void insertrecord(String strSQL){
		initConnection();
		try {
			Statement stmt=zayodbConnection.createStatement();
			stmt.execute(strSQL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		closeConnection();
	}
	
	public static ResultSet readrecord(String qSQL){
		System.out.println("Strat connection");
		initConnection();
		ResultSet r = null;
		try {
			System.out.println("Strat Query");
			Statement stmt=zayodbConnection.createStatement();
			r = stmt.executeQuery(qSQL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		//closeConnection();
		return r;
	}
	
	public static void main(String[] arg){
		zObjManager manobj = new zObjManager();
		//manobj.setManagerFirstName("Animesh");
		//manobj.setManagerLastName("Das");
		//manobj.setManagerEmail("Animesh.das738@gmail.com");
		//manobj.setManagerPhone("+91 9836948217");
		manobj.createZObject();
		//manobj.updateZObject();
		manobj.convertDBResultSet(readrecord(manobj.readDBStatementZObject()));
		System.out.println("Name:" + manobj.getManagerFirstName() + " " + manobj.getManagerLastName());
		System.out.println("Phone:" + manobj.getManagerPhone());
	}
	
	public static zObjManager searchmanager(){
		zObjManager manobj = new zObjManager();
		manobj.convertDBResultSet(readrecord(manobj.readDBStatementZObject()));
		System.out.println("Name:" + manobj.getManagerFirstName() + " " + manobj.getManagerLastName());
		System.out.println("Phone:" + manobj.getManagerPhone());
		return manobj;
	}
}
