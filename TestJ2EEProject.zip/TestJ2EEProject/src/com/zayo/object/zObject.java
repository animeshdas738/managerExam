package com.zayo.object;

import java.sql.ResultSet;

public interface zObject {

	public void createZObject();
	public void updateZObject();
	public void deleteZObject();
	
	public String insertDBStatementZObject();
	public String updateDBStatementZObject();
	public String deleteDBStatementZObject();
	public String readDBStatementZObject();
	public void convertDBResultSet(ResultSet dbres);
}
