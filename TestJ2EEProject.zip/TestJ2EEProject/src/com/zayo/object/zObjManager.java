package com.zayo.object;

import java.util.*;

import com.zayo.database.zayodbConnection;

import java.sql.*;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class zObjManager implements zObject{
	private String recordId;
	private java.util.Date createdDate;
	private String createdBy;
	private java.util.Date modifiedDate;
	private String modifiedBy;
	private String managerFirstName;
	private String managerLastName;
	private String managerMiddleName;
	private String managerEmail;
	private String managerPhone;
	private String managerMobile;
	private String managerFax;
	private java.util.Date managerDOB;
	private String managerDepartment;
	private String managerFunction;
	private String managerAccount;
	private String managerStatus;
	private Boolean managerIsDeleted;
	
	public String getManagerStatus() {
		return managerStatus;
	}

	public void setManagerStatus(String managerStatus) {
		this.managerStatus = managerStatus;
	}

	public Boolean getManagerIsDeleted() {
		return managerIsDeleted;
	}
	
	public String getRecordId() {
		return recordId;
	}
	
	public java.util.Date getCreatedDate() {
		return createdDate;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	
	public java.util.Date getModifiedDate() {
		return modifiedDate;
	}
	
	public String getModifiedBy() {
		return modifiedBy;
	}
	
	public String getManagerFirstName() {
		return managerFirstName;
	}
	
	public void setManagerFirstName(String managerFirstName) {
		this.managerFirstName = managerFirstName;
	}
	
	public String getManagerLastName() {
		return managerLastName;
	}
	
	public void setManagerLastName(String managerLastName) {
		this.managerLastName = managerLastName;
	}
	
	public String getManagerMiddleName() {
		return managerMiddleName;
	}
	
	public void setManagerMiddleName(String managerMiddleName) {
		this.managerMiddleName = managerMiddleName;
	}
	
	public String getManagerEmail() {
		return managerEmail;
	}
	
	public void setManagerEmail(String managerEmail) {
		this.managerEmail = managerEmail;
	}
	
	public String getManagerPhone() {
		return managerPhone;
	}
	
	public void setManagerPhone(String managerPhone) {
		this.managerPhone = managerPhone;
	}
	
	public String getManagerMobile() {
		return managerMobile;
	}
	
	public void setManagerMobile(String managerMobile) {
		this.managerMobile = managerMobile;
	}
	
	public String getManagerFax() {
		return managerFax;
	}
	
	public void setManagerFax(String managerFax) {
		this.managerFax = managerFax;
	}
	
	public java.util.Date getManagerDOB() {
		return managerDOB;
	}
	
	public void setManagerDOB(Date managerDOB) {
		this.managerDOB = managerDOB;
	}
	
	public String getManagerDepartment() {
		return managerDepartment;
	}
	
	public void setManagerDepartment(String managerDepartment) {
		this.managerDepartment = managerDepartment;
	}
	
	public String getManagerFunction() {
		return managerFunction;
	}
	
	public void setManagerFunction(String managerFunction) {
		this.managerFunction = managerFunction;
	}
	
	public String getManagerAccount() {
		return managerAccount;
	}
	
	public void setManagerAccount(String managerAccount) {
		this.managerAccount = managerAccount;
	}
	
	public void createZObject(){
		this.recordId = "afvsudvfuysfdtf";
		java.util.Date datetimenow = new java.util.Date();
		this.createdDate = datetimenow;
		this.modifiedDate = datetimenow;
		this.createdBy = "";
		this.modifiedBy = "";
	}
	
	public void updateZObject(){
		java.util.Date datetimenow = new java.util.Date();
		this.modifiedDate = datetimenow;
		this.modifiedBy = "";
	}
	
	public void deleteZObject(){
		this.managerIsDeleted = true;
	}
	
	public String insertDBStatementZObject(){
		StringBuilder r = new StringBuilder();
		r.append("INSERT INTO ZAYO_ZOBJMANAGER (RECORDID,");
		r.append("MANAGERFIRSTNAME,");
		r.append("MANAGERLASTNAME,");
		r.append("MANAGERMIDDLENAME,");
		r.append("MANAGEREMAIL,");
		r.append("MANAGERPHONE,");
		r.append("MANAGERMOBILE,");
		r.append("MANAGERFAX,");
		r.append("MANAGERDOB,");
		r.append("MANAGERDEPARTMENT,");
		r.append("MANAGERFUNCTION,");
		r.append("MANAGERACCOUNT,");
		r.append("MANAGERSTATUS,");
		r.append("MANAGERISDELETED,");
		r.append("CREATEDDATE,");
		r.append("MODIFIEDDATE,");
		r.append("CREATEDBY,");
		r.append("MODIFIEDBY) VALUES(");
		r.append("'" + String.valueOf(this.getRecordId()) + "',");
		r.append("'" + String.valueOf(this.getManagerFirstName()) + "',");
		r.append("'" + String.valueOf(this.getManagerLastName()) + "',");
		r.append("'" + String.valueOf(this.getManagerMiddleName()) + "',");
		r.append("'" + String.valueOf(this.getManagerEmail()) + "',");
		r.append("'" + String.valueOf(this.getManagerPhone()) + "',");
		r.append("'" + String.valueOf(this.getManagerMobile()) + "',");
		r.append("'" + String.valueOf(this.getManagerFax()) + "',");
		r.append("NULL,");
		r.append("'" + String.valueOf(this.getManagerDepartment()) + "',");
		r.append("'" + String.valueOf(this.getManagerFunction()) + "',");
		r.append("'" + String.valueOf(this.getManagerAccount()) + "',");
		r.append("'" + String.valueOf(this.getManagerStatus()) + "',");
		r.append("'" + String.valueOf(this.getManagerIsDeleted()) + "',");
		r.append("NULL,");
		r.append("NULL,");
		r.append("NULL,");
		r.append("NULL" + ")");
		System.out.println(r);
		return r.toString();
	}
	public String updateDBStatementZObject(){
		StringBuilder r = new StringBuilder();
		r.append("UPDATE ZAYO_ZOBJMANAGER SET ");
		r.append("MANAGERFIRSTNAME = '" + String.valueOf(this.getManagerFirstName()) + "',");
		r.append("MANAGERLASTNAME = '" + String.valueOf(this.getManagerLastName()) + "',");
		r.append("MANAGERMIDDLENAME = '" + String.valueOf(this.getManagerMiddleName()) + "',");
		r.append("MANAGEREMAIL = '" + String.valueOf(this.getManagerEmail()) + "',");
		r.append("MANAGERPHONE = '" + String.valueOf(this.getManagerPhone()) + "',");
		r.append("MANAGERMOBILE = '" + String.valueOf(this.getManagerMobile()) + "',");
		r.append("MANAGERFAX = '" + String.valueOf(this.getManagerFax()) + "',");
		r.append("MANAGERDOB = " + "NULL" + ",");
		r.append("MANAGERDEPARTMENT = '" + String.valueOf(this.getManagerDepartment()) + "',");
		r.append("MANAGERFUNCTION = '" + String.valueOf(this.getManagerFunction()) + "',");
		r.append("MANAGERACCOUNT = '" + String.valueOf(this.getManagerAccount()) + "',");
		r.append("MANAGERSTATUS = '" + String.valueOf(this.getManagerStatus()) + "',");
		r.append("MANAGERISDELETED = '" + String.valueOf(this.getManagerIsDeleted()) + "',");
		r.append("MODIFIEDDATE = " + "SYSTIMESTAMP" + ",");
		r.append("CREATEDBY = " + "NULL" + ",");
		r.append("MODIFIEDBY = " + "NULL ");
		r.append("WHERE RECORDID = '" + this.getRecordId() + "'");
		System.out.println(r);
		return r.toString();
	}
	public String deleteDBStatementZObject(){
		String r = null;
		
		return r;
	}
	
	public String readDBStatementZObject(){
		String r = null;
		r = "SELECT * FROM ZAYO_ZOBJMANAGER WHERE RECORDID = '" + this.getRecordId() + "'";
		return r;
	}
	public void convertDBResultSet(ResultSet dbres){
		try {
			while(dbres.next()){
				this.setManagerFirstName(dbres.getString("MANAGERFIRSTNAME"));
				this.setManagerLastName(dbres.getString("MANAGERLASTNAME"));
				this.setManagerMiddleName(dbres.getString("MANAGERMIDDLENAME"));
				this.setManagerEmail(dbres.getString("MANAGEREMAIL"));
				this.setManagerPhone(dbres.getString("MANAGERPHONE"));
				this.setManagerMobile(dbres.getString("MANAGERMOBILE"));
				this.setManagerFax(dbres.getString("MANAGERFAX"));
			}
			dbres.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void testsearch(){
		convertDBResultSet(zayodbConnection.readrecord(this.readDBStatementZObject()));
	}
}
